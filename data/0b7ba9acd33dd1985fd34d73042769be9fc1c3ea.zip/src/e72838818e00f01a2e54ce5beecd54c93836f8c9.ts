import { test, expect } from "@playwright/test";

test("TID-001: Register User", async ({ page }) => {
  // Make registration unique each run by using a timestamp.

  const timestamp = Date.now();
  const name = "qatest1234";
  const uniqueEmail = `qatest1234.${timestamp}@example.com`;
  const password = "Test@1234";

  // Intercept ads using a list of ad domains and abort the request
  await page.route("**/*", async (route) => {
    const url = route.request().url();

    if (
      url.includes("doubleclick.net") ||
      url.includes("googlesyndication.com") ||
      url.includes("adservice.google.com") ||
      url.includes("ads.pubmatic.com") ||
      url.includes("securepubads.g.doubleclick.net") ||
      url.includes("pagead2.googlesyndication.com") ||
      url.includes("ads.google.com")
    ) {
      await route.abort();
    } else {
      await route.continue();
    }
  });

  // TEST STEPS

  // Steps 1-4: Launch and confirm home page loads, check if the "New User Signup!" text is visible
  // "/login" is the domain for both login and registration, so we can use it to confirm the home page loads.
  await test.step("Launch browser and confirm home page loads", async () => {
    await page.goto("/");
  });

  await test.step("Check if the 'New User Signup!' text is visible", async () => {
    await page.getByRole("link", { name: " Signup / Login" }).click();
    await expect(page.getByText("New User Signup!")).toBeVisible();
  });

  // Step 5: Enter name + email in the signup form, click Signup
  await test.step("Enter name + email in the signup form, click Signup", async () => {
    await page.locator('[data-qa="signup-name"]').fill(name);
    await page.locator('[data-qa="signup-email"]').fill(uniqueEmail);
    await page.locator('[data-qa="signup-button"]').click();
  });

  // Step 6: Confirm the account information form appeared
  await test.step("Confirm the account information form appeared", async () => {
    await expect(page.getByText("ENTER ACCOUNT INFORMATION")).toBeVisible();
  });

  // Step 7: Fill in account details
  await test.step("Fill in account details", async () => {
    await page.locator("#id_gender1").check(); // Title: Mr
    await page.locator("#password").fill(password);
    await page.locator("#days").selectOption("10");
    await page.locator("#months").selectOption("5");
    await page.locator("#years").selectOption("1995");
  });

  // Step 8: Newsletter + special offers checkboxes
  await test.step("Newsletter + special offers checkboxes", async () => {
    await page.locator("#newsletter").check();
    await page.locator("#optin").check();
  });

  // Step 9: Address details
  await test.step("Address details", async () => {
    await page.locator("#first_name").fill("QA");
    await page.locator("#last_name").fill("Test");
    await page.locator("#company").fill("QA Company");
    await page.locator("#address1").fill("123 Test Street");
    await page.locator("#country").selectOption("United States");
    await page.locator("#state").fill("NY");
    await page.locator("#city").fill("New York");
    await page.locator("#zipcode").fill("10001");
    await page.locator("#mobile_number").fill("5555555555");
  });

  // Step 10: Create Account
  await test.step("Click Create Account", async () => {
    await page.locator('[data-qa="create-account"]').click();
  });

  // Step 11: Confirm account created, then Continue
  await test.step("Confirm account created, then Continue", async () => {
    await expect(page.getByText("ACCOUNT CREATED!")).toBeVisible();
    await page.locator('[data-qa="continue-button"]').click();
  });

  // Step 12: Confirm logged in
  await test.step("Confirm logged in", async () => {
    await expect(page.getByText(`Logged in as ${name}`)).toBeVisible();
  });

  // Step 13: Delete Account
  // Check if Delete Account button is visible before clicking it
  await test.step("Delete Account", async () => {
    await expect(
      page.getByRole("link", { name: "Delete Account" }),
    ).toBeVisible();
    await page.getByRole("link", { name: "Delete Account" }).click();

    // Step 14: Confirm account deleted, then Continue
    await expect(page.getByText("ACCOUNT DELETED!")).toBeVisible();
  });
});
